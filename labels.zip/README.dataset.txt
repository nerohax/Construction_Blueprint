# My First Project > 2025-06-01 9:45am
https://universe.roboflow.com/workspace-9gqpx/my-first-project-odguc

Provided by a Roboflow user
License: CC BY 4.0

